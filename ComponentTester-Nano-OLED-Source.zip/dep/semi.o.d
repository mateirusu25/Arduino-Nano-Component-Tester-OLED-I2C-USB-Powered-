semi.o: semi.c config.h config_328.h common.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/stdio.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/inttypes.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/stdint.h \
  c:\winavr-20100110\bin\../lib/gcc/avr/4.3.3/include/stdarg.h \
  c:\winavr-20100110\bin\../lib/gcc/avr/4.3.3/include/stddef.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/stdlib.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/string.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/math.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/io.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/sfr_defs.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/iom328p.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/portpins.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/common.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/version.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/fuse.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/lock.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/util/delay.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/util/delay_basic.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/sleep.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/eeprom.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/pgmspace.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/wdt.h \
  c:/winavr-20100110/lib/gcc/../../avr/include/avr/interrupt.h \
  variables.h colors.h functions.h

config.h:

config_328.h:

common.h:

c:/winavr-20100110/lib/gcc/../../avr/include/stdio.h:

c:/winavr-20100110/lib/gcc/../../avr/include/inttypes.h:

c:/winavr-20100110/lib/gcc/../../avr/include/stdint.h:

c:\winavr-20100110\bin\../lib/gcc/avr/4.3.3/include/stdarg.h:

c:\winavr-20100110\bin\../lib/gcc/avr/4.3.3/include/stddef.h:

c:/winavr-20100110/lib/gcc/../../avr/include/stdlib.h:

c:/winavr-20100110/lib/gcc/../../avr/include/string.h:

c:/winavr-20100110/lib/gcc/../../avr/include/math.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/io.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/sfr_defs.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/iom328p.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/portpins.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/common.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/version.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/fuse.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/lock.h:

c:/winavr-20100110/lib/gcc/../../avr/include/util/delay.h:

c:/winavr-20100110/lib/gcc/../../avr/include/util/delay_basic.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/sleep.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/eeprom.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/pgmspace.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/wdt.h:

c:/winavr-20100110/lib/gcc/../../avr/include/avr/interrupt.h:

variables.h:

colors.h:

functions.h:
